<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>Ваш клуб '[club_name]' стал клубом верхнего уровня. Он теперь может использоваться как система клубов.</p>\r\n<p><a href=\"[root]/club_main.php?_login_=[user_id]&id=[club_id]\">Нажмите здесь</a> если хотите сделать с [club_name] что-то еще.</p>",
	"Здравствуйте [user_name],\r\n\r\nВаш клуб '[club_name]' стал клубом верхнего уровня. Он теперь может использоваться как система клубов.\r\n\r\nЗайдите на этот линк [root]/club_main.php?_login_=[user_id]&id=[club_id] если хотите сделать с [club_name] что-то еще.\r\n"
);

?>