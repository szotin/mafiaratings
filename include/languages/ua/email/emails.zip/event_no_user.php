<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>" . PRODUCT_NAME . " не может идентифицировать некоторых игроков ([incomers]) игравших в клубе [club_name] ([address]) [event_date] [event_time].</p>\r\n<p>Пожалуйста <a href=\"[url]\">нажмите здесь</a> если вы знаете, кто это был.</p>",
	"Здравствуйте [user_name],\r\n\r\n" . PRODUCT_NAME . " не может идентифицировать некоторых игроков ([incomers]) игравших в клубе [club_name] ([address]) [event_date] [event_time].\r\n\r\nПожалуйста скажите кто это здесь [url], если вы знаете, кто это был.</p>"
);

?>