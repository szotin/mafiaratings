<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>Даем вам знать о том, что [sender] исключил ваш клуб [club_name] из [league_name].</p><p>[message]</p>",
	"Здравствуйте [user_name],\r\n\r\nДаем вам знать о том, что [sender] исключил ваш клуб [club_name] из [league_name].\r\n\r\n[message]\r\n"
);

?>