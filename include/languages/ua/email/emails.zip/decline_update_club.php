<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>Ваш запрос на изменение статуса клуба [club_name] отклонен.</p>\r\n<p>Причина:\r\n<br>[reason]<p>",
	"Здравствуйте [user_name],\r\n\r\nВаш запрос на изменение статуса клуба [club_name] отклонен.\r\n\r\nПричина:\r\n[reason]\r\n"
);

?>