<?php

return array
(
	'[club_name]',
	"Здравствуйте [user_name],\r\n<br>\r\n<br>мы отменили <b>[event_name]</b> [event_date] [event_time].\r\n<br>\r\n<br>Извините за неудобства.<hr>[unsub]Нажмите здесь[/unsub] если Вы хотите отписаться от рассылки.",
	"Здравствуйте [user_name],\r\n\r\nмы отменили [event_name] [event_date] [event_time].\r\n\r\nИзвините за неудобства.",
);

?>