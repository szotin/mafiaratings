<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] послал запрос о создании лиги (объединения клубов) \"[league_name]\". <a href=\"[root]/leagues.php?_login_=[user_id]\">Пожалуйста подтвердите</a>.</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] послал запрос о создании лиги (объединения клубов) \"[league_name]\". Пожалуйста подтвердите здесь [root]/leagues.php?_login_=[user_id].\r\n"
);

?>