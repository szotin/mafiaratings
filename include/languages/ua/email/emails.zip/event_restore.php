<?php

return array
(
	'[club_name]',
	"Здравствуйте [user_name],\r\n<br>\r\n<br>мы решили все таки провести <b>[event_name]</b> в <a href=\"[address_url]\" target=\"_blank\">[address]</a> [event_date] [event_time]. Он больше не отменен.\r\n<br>\r\n<br>[notes]\r\n<br>\r\n<br>Если Вы придете не один, то это только приветствуется.\r\n<br>Пожалуйста дайте нам знать, придете ли Вы:\r\n<br>[accept_btn=Да, я приду] [decline_btn=Нет, не в этот раз]\r\n<br>\r\n<br>Ждем Вас с нетерпением.<hr>[unsub]Нажмите здесь[/unsub] если Вы хотите отписаться от рассылки.",
	"Здравствуйте [user_name],\r\n\r\nмы решили все таки провести [event_name] в [address] [event_date] [event_time]. Он больше не отменен.\r\n\r\n[notes]\r\n\r\nЕсли Вы придете не один, то это только приветствуется.\r\nbr>Пожалуйста дайте нам знать, придете ли Вы:\r\n[root]/event_info.php?id=[event_id].",
);

?>