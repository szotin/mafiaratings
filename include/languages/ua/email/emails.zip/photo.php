<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name]!</p>\r\n<p>Вы были отмечены на [pcount] фото:</p>\r\n<p>[photos]</p><hr>\r\n<p>Нажмите [unsub]отписаться[/unsub] если вы не хотите больше получать письма когда кто-то отмечает вас на фотографиях в " . PRODUCT_NAME . ".</p>",
	"Здравствуйте [user_name]!\r\n\r\nВы были отмечены на [pcount] фото:\r\n\r\n[photos]\r\n"
);

?>