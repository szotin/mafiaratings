<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] просит включить свой клуб [club_name] в лигу [league_name]. <a href=\"[root]/league_clubs.php?id=[league_id]&_login_=[user_id]\">Пожалуйста подтвердите, или откажитесь</a>.</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] просит включить свой клуб [club_name] в лигу [league_name]. Пожалуйста подтвердите, или откажитесь [root]/league_clubs.php?id=[league_id]&_login_=[user_id].\r\n"
);

?>