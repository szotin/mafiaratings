<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] прокомментировал фотографию:</p>\r\n<p>[photo]</p>\r\n<p>[message]</p>\r\n<p><a href=\"[url]\">Нажмите сюда, чтобы ответить.</a></p><hr>\r\n<p>Нажмите [unsub]отписаться[/unsub] если вы не хотите больше получать письма об активности в форуме " . PRODUCT_NAME . ".</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] прокомментировал фотографию:\r\n\r\n[photo]\r\n-----\r\n[message]\r\n-----\r\nПройдите сюда [url], чтобы ответить.\r\n"
);

?>