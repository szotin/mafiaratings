<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>Клуб [club_name] был создан для Вас. Мы дали вам менеджерские права в этом клубе.</p>\r\n<p><a href=\"[root]/club_main.php?_login_=[user_id]&id=[club_id]\">Нажмите здесь</a> чтобы завершить создание клуба.</p>",
	"Здравствуйте [user_name],\r\n\r\nКлуб [club_name] был создан для Вас. Мы дали вам менеджерские права в этом клубе.\r\n\r\nПройдите сюда [root]/club_main.php?_login_=[user_id]&id=[club_id], чтобы завершить создание клуба.\r\n"
);

?>