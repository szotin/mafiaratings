<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] послал запрос о создании клуба \"[club_name]\". <a href=\"[root]/club_requests.php?_login_=[user_id]\">Пожалуйста подтвердите</a>.</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] послал запрос о создании клуба \"[club_name]\". Пожалуйста подтвердите здесь [root]/club_requests.php?_login_=[user_id].\r\n"
);

?>