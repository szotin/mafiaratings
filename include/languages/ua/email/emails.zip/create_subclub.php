<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] послал запрос о создании клуба \"[club_name]\" в вашей системе клубов \"[parent_name]\". <a href=\"[root]/club_requests.php?_login_=[user_id]&club_id=[parent_id]\">Пожалуйста подтвердите</a>.</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] послал запрос о создании клуба \"[club_name]\" в вашей системе клубов \"[parent_name]\". Пожалуйста подтвердите здесь [root]/club_requests.php?_login_=[user_id]&club_id=[parent_id].\r\n"
);

?>