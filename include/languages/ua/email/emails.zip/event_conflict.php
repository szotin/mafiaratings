<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте все,</p>\r\n<p>два игрока [user_name1] и [user_name2] заявили, что играли под псевдонимом [nick] в [club_name] ([address]) [event_date] [event_time].</p>\r\n<p>Выясните, пожалуйста, кто из них играл на самом деле.</p>",
	"Здравствуйте все,\r\n\r\nдва игрока [user_name1] и [user_name2] заявили, что играли под псевдонимом [nick] в [club_name] ([address]) [event_date] [event_time].\r\n\r\nВыясните, пожалуйста, кто из них играл на самом деле.\r\n"
);

?>