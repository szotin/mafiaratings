<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] из [club_name] удалил турнир \"[tournament_name]\" на [stars] звезд (<big>[stars_str]</big>) из [league_name] [series_name]. <a href=\"[root]/tournament_info.php?id=[tournament_id]&_login_=[user_id]\">Пожалуйста проверьте здесь, все ли правильно</a>.</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] из [club_name] удалил турнир \"[tournament_name]\" на [stars] звезд ([stars_str]) из [league_name] [series_name]. Пожалуйста проверьте здесь, все ли правильно [root]/tournament_info.php?id=[tournament_id]&_login_=[user_id].\r\n"
);

?>