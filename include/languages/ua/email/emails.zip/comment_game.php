<?php

return array
(
	PRODUCT_NAME,
	"<p>Здравствуйте [user_name],</p>\r\n<p>[sender] прокомментировал игру №[gid]:</p>\r\n<p><font color=\"#505050\">[message]</font></p>\r\n<p><a href=\"[url]\">Нажмите сюда, чтобы ответить.</a></p><hr>\r\n<p>Нажмите [unsub]отписаться[/unsub] если вы не хотите больше получать письма об активности в форуме " . PRODUCT_NAME . ".</p>",
	"Здравствуйте [user_name],\r\n\r\n[sender] прокомментировал игру №[gid]:\r\n-----\r\n[message]\r\n-----\r\nПройдите сюда [url], чтобы ответить.\r\n"
);

?>